import"./chunk-B5Qt9EMX.js";chrome.devtools.panels.create("HybridForms","/img/FAVicon_HybridForms-blue32.png","/pages/panel.html");
